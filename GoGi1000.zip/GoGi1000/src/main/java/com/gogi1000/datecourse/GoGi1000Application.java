package com.gogi1000.datecourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication
public class GoGi1000Application {

	public static void main(String[] args) {
		SpringApplication.run(GoGi1000Application.class, args);
	}

}

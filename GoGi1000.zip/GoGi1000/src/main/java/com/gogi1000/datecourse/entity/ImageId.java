package com.gogi1000.datecourse.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class ImageId implements Serializable{
     private String imageGroup;
     private int referenceNo;
     
}

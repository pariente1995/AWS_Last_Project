package com.gogi1000.datecourse.service.datecourse.impl;

import org.springframework.stereotype.Service;

@Service
public class DatecourseServiceImpl {

}

package com.gogi1000.datecourse.service.hotdeal;

public interface HotdealService {

}

package com.gogi1000.datecourse.service.like;

public interface LikeService {

}

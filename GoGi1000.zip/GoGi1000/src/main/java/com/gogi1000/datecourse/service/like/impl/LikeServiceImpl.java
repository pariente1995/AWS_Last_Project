package com.gogi1000.datecourse.service.like.impl;

import org.springframework.stereotype.Service;

@Service
public class LikeServiceImpl {

}

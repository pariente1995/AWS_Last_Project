package com.gogi1000.datecourse.service.main.Impl;

public class MainServiceImpl {

}

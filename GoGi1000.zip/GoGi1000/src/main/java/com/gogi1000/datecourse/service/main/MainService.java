package com.gogi1000.datecourse.service.main;

import java.util.List;

import com.gogi1000.datecourse.entity.Datecourse;

public interface MainService {
	List<Datecourse> getDatecourseList(Datecourse datecourse);
}

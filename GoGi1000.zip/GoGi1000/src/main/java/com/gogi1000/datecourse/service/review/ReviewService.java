package com.gogi1000.datecourse.service.review;

public interface ReviewService {

}

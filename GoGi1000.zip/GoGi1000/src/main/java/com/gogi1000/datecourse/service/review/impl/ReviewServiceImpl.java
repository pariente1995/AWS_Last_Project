package com.gogi1000.datecourse.service.review.impl;

import org.springframework.stereotype.Service;

@Service
public class ReviewServiceImpl {

}

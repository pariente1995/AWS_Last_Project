package com.gogi1000.datecourse.service.user;

public interface UserService {
}

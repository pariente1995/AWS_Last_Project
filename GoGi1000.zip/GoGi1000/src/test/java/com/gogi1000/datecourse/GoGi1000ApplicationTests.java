package com.gogi1000.datecourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoGi1000ApplicationTests {

	@Test
	void contextLoads() {
	}

}
